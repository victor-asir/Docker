
require "checks.rb"

module Checks
  class ActionsTraces < Base
    # Setters
    def self.search_text(search_text)
      @search_text = search_text
    end

    def self.looking_for(looking_for)
      @looking_for = looking_for
    end

    # Getters
    def search_text
      self.class.instance_variable_get("@search_text")
    end

    def looking_for
      self.class.instance_variable_get("@looking_for")
    end

    def run
      return needs_root unless running_as_root?

      checked_at_least_one_log = false

      ACTIONS_SERVICES.each do |service|
        if File.directory?("/data/user/actions/lightrail/#{service}/logs")
          checked_at_least_one_log = true
          exit_code, _ = run_bash "grep '#{search_text}' /data/user/actions/lightrail/#{service}/logs/LR_* 2>&1"
          return fail("Found evidence of #{looking_for}") if exit_code == 0
        end
      end

      if File.directory?('/data/user/nomad/alloc')
        checked_at_least_one_log = true
        exit_code, _ = run_bash "grep -r -F '#{search_text}' /data/user/nomad/alloc 2>&1"
        return fail("Found evidence of #{looking_for}") if exit_code == 0
      end

      return skipped("No Actions Log file") unless checked_at_least_one_log

      pass "No evidence of #{looking_for}"
    end
  end
end
