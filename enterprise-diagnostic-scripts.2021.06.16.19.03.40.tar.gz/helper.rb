#!/usr/bin/env ruby

class Helper
  attr_reader :license_seats, :total_users, :suspended_users, :active_seats

  def initialize(log_file, options)
    @log_file = log_file
    _, text = run_bash %q( /usr/local/share/enterprise/ghe-license-info 2>&1 | grep -Po '^\"seats\"\h?:\h?\K[\d]+' 2>&1 )
    @license_seats = text.to_i
    _, text = run_bash "curl -s 127.0.0.1:1337/api/v3/enterprise/stats/all | jq .users.total_users"
    @total_users = text.to_i
    _, text = run_bash "curl -s 127.0.0.1:1337/api/v3/enterprise/stats/all | jq .users.suspended_users"
    @suspended_users = text.to_i
    @active_seats = total_users - suspended_users

    unless options[:active_seats].nil?
      log_detail "There are #{@active_seats} active seats, but #{options[:active_seats]} we spefied at the command line, will use that"
      @active_seats = options[:active_seats]
    end
  end

  def log(msg)
    line = "[#{Time.now}] #{msg}"
    @log_file.puts line
    $stdout.puts line
  end

  def log_detail(msg)
    line = "[#{Time.now}] #{msg}"
    @log_file.puts line
  end

  def run_bash(command, options = {})
    log_detail "Running: #{command}#{ " (silent)" if options[:silent] }"
    text = %x( #{command} )
    exit_code = $?.exitstatus
    log_detail "Exit Code: #{exit_code}"
    unless options[:silent]
      log_detail "Result from the command:"
      log_detail text
    end
    return exit_code, text
  end

  def run_bash_silent(command, options = {})
    run_bash command, options.merge(silent: true)
  end

  def log_version
    exit_code, _ = run_bash "[ -d .git ]"
    if exit_code == 0
      _, version = run_bash "git rev-parse HEAD"
    elsif File.file? 'version'
      file = File.open 'version'
      version = file.read
    else
      version = "unknown"
    end
    log "Running version: #{version.strip}"
  end

  def running_as_root?
    _, text = run_bash "whoami"
    "root".eql? text.strip
  end 

  def self.get_min_vcpus(seats)
    return 4 if seats < 10
    return 8 if seats.between?(10,2999)
    return 12 if seats.between?(3000,4999)
    return 16 if seats.between?(5000,7999)
    20
  end

  def self.get_min_memory_gb(seats)
    return 32 if seats < 10
    return 48 if seats.between?(10,2999)
    return 64 if seats.between?(3000,4999)
    return 96 if seats.between?(5000,7999)
    160
  end

  def self.get_min_attached_storage_gb(seats)
    return 150 if seats < 10
    return 300 if seats.between?(10,2999)
    return 500 if seats.between?(3000,4999)
    return 750 if seats.between?(5000,7999)
    1000
  end
end