#!/usr/bin/env ruby

require "checks.rb"

module Checks
  class MsSqlDiagnostic < Base
    def check_ms_sql
      # Define in child classes
    end

    def run
      return needs_root unless running_as_root?

      return skipped("Did not find MSSQL Error Log") unless File.file?('/data/user/mssql/log/errorlog')

      check_ms_sql
    end
  end
end

class MSSqlPageAllocationFailures < Checks::MsSqlDiagnostic
  name "MSSQL Page Allocation Failures"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/26"

  def check_ms_sql
    exit_code, _ = run_bash 'grep "Failed allocate pages" /data/user/mssql/log/errorlog 2>&1'

    if exit_code == 0
      fail "Page Allocations Failures Detected"
    else
      pass "No Page Allocation Failures Detected"
    end
  end
end

class MSSqlAllocatedMemory < Checks::MsSqlDiagnostic
  name "MSSQL Allocated Memory"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/27"

  def check_ms_sql
    #looking for
    # 2021-01-30 21:03:16.11 Server      Detected 5079 MB of RAM. This is an informational message; no user action is required.
    exit_code, text = run_bash 'grep ".*Server.*Detected .* of RAM\. This is an informational message; no user action is required\." /data/user/mssql/log/errorlog 2>&1'
    if exit_code == 0
      memory_mb = 0

      text.each_line do |line|
        line.strip!
        if line.length > 0
          matches = line.match /(?:.*)Server(?:.*)Detected (?<amount>\d+) (?<unit>\w+) of RAM. This is an informational message; no user action is required./
          unless matches.nil?
            if "MB".eql? matches[:unit]
              memory_mb = matches[:amount].to_i
              log_detail "Found allocation for #{memory_mb}MB"
            else
              log_detail "Unexpected Unit #{matches[:unit]}"
            end
          end 
        end
      end

      return skipped("Failed to find MSSQL Memory Allocation") if memory_mb == 0

      return fail("Only found #{memory_mb}MB Allocated my MSSQL, which is less than 2GB") if memory_mb < 2 * 1024 # 2GB

      pass "Found #{memory_mb}MB Allocated my MSSQL, which meets the 2GB limit"

    else
      skipped "No OOM Memory Allocation Failures Detected"
    end
  end
end

class MSSqlOomMemoryAllocationFailures < Checks::MsSqlDiagnostic
  name "MSSQL OOM Memory Allocation Failures"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/28"

  def check_ms_sql
    exit_code, _ = run_bash 'grep "There was a memory allocation failure during connection establishment" /data/user/mssql/log/errorlog 2>&1'
    if exit_code == 0
      fail "OOM Memory Allocations Failures Detected"
    else
      pass "No OOM Memory Allocation Failures Detected"
    end
  end
end

class MSSqlHealthCheck < Checks::MsSqlDiagnostic
  name "MSSQL Health Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/29"

  def check_ms_sql
    exit_code, _ = run_bash %q( ghe-mssql-console -y -q "print CONCAT(@@SERVERNAME, ' is alive')" 2>&1)
    if exit_code == 0
      pass "MSSQL Help check Passed"
    else
      fail "Failed to execute basic query"
    end
  end
end

class MSSqlStateCheck < Checks::MsSqlDiagnostic
  name "MSSQL State Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/30"

  def check_ms_sql
    exit_code, text = run_bash %q( ghe-mssql-console -y -n -r -q "
        SET NOCOUNT ON;
        SELECT name, state_desc 
        FROM   sys.databases
        WHERE  state_desc != 'ONLINE'
        " 2>&1)
    text.strip!

    return fail("Could not get Database Statuses") unless exit_code == 0

    return fail("At least one Database is Not ONLINE") unless text.length == 0
    
    pass "All Databases are Online"
  end
end

class MSSqlMissingAvailabilityGroup < Checks::MsSqlDiagnostic
  name "MSSQL Missing Availability Group"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/41"

  def check_ms_sql
    exit_code, _ = run_bash 'grep "The availability replica is not found in the availability group configuration" /data/user/mssql/log/errorlog 2>&1'
    if exit_code == 0
      fail "Found an missing availability group"
    else
      pass "No missing availability group"
    end
  end
end

class MSSqlSeedingInProgress < Checks::MsSqlDiagnostic
  name "MSSQL Seeding In Progress"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/43"

  def check_ms_sql
    exit_code, text = run_bash %q( ghe-mssql-console -y -n -r -q "
        SET NOCOUNT ON;
        SELECT operational_state_desc,
               connected_state_desc,
               recovery_health_desc,
               synchronization_health_desc 
        FROM   sys.dm_hadr_availability_replica_states
        WHERE  operational_state_desc = 'ONLINE'
               AND connected_state_desc = 'CONNECTED'
               AND recovery_health_desc = 'ONLINE_IN_PROGRESS'
               AND synchronization_health_desc = 'NOT_HEALTHY'
        " 2>&1)
    text.strip!

    return fail("Could not get availability replica state") unless exit_code == 0

    return fail("Seeding appears to be in progress") unless text.length == 0

    pass "Seeding does not appear to be in progress"
  end
end

class MSSqlReplicaState < Checks::MsSqlDiagnostic
  name "MSSQL Replica State"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/46"

  def check_ms_sql
    exit_code, text = run_bash %q( ghe-mssql-console -y -n -r -q "
        SET NOCOUNT ON;
        SELECT operational_state_desc,
               connected_state_desc,
               recovery_health_desc,
               synchronization_health_desc
        FROM   sys.dm_hadr_availability_replica_states
        WHERE  is_local = 1
               AND (operational_state_desc IN('PENDING', 'PENDING_FAILOVER', 'OFFLINE', 'FAILED', 'FAILED_NO_QUORUM')
                    OR connected_state_desc = 'DISCONNECTED'
                    OR recovery_health_desc = 'ONLINE_IN_PROGRESS'
                    OR synchronization_health_desc IN('NOT_HEALTHY', 'PARTIALLY_HEALTHY'))
        " 2>&1)
    text.strip!

    return fail("Could not get availability replica state") unless exit_code == 0

    return fail("Found replication in an unexpected State") unless text.length == 0

    pass "No Replication state problems found"
  end
end

class MSSqlDatabaseBackups < Checks::MsSqlDiagnostic
  name "MSSQL Database backups"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/74"

  def check_ms_sql
    exit_code, recoverable_dbs = run_bash %q( ghe-mssql-console -y -n -q "
        SET NOCOUNT ON; 
        SELECT name
        FROM   sys.databases
        WHERE  sys.databases.recovery_model_desc = 'FULL'
               AND name NOT IN('master', 'tempdb', 'model', 'msdb')
        " 2>&1)

    recoverable_dbs.strip!

    return fail("Could not check for recoverable DBs") unless exit_code == 0

    return skipped("Did not find any recoverable DBs") if recoverable_dbs.length == 0

    _, backup_interval_days_text = run_bash "ghe-config app.actions.backup.interval.days"
    backup_interval_days_text.strip!
    if backup_interval_days_text.length == 0
      backup_interval_days = 14
      log_detail "app.actions.backup.interval.days not set, defaulting #{backup_interval_days}"
    else
      backup_interval_days = backup_interval_days_text.to_i
    end

    recoverable_dbs.each_line do |db|
      db.strip!

      # Find the age of the last backup
      exit_code, last_backup_age = run_bash "ghe-mssql-console -y -n -q \"
        SET NOCOUNT ON;
        SELECT MIN(DATEDIFF(DAY, msdb.dbo.backupset.backup_finish_date, GETUTCDATE()))
        FROM   msdb.dbo.backupset
        WHERE  msdb.dbo.backupset.database_name = '#{db}'
        \" 2>&1"

      last_backup_age.strip!

      return fail("Could not check backup finish date") unless exit_code == 0

      return fail("Found no backups for #{db}") if last_backup_age.eql? "NULL"

      return fail("The last backup for #{db} was #{last_backup_age} days old, which is more than the limit of #{backup_interval_days} days") if last_backup_age.to_i > backup_interval_days
    end

    pass "All database backup are newer than #{backup_interval_days} days old"
  end
end

class MSSqlTransactionLogs < Checks::MsSqlDiagnostic
  name "MSSQL Transaction Logs"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/79"

  def check_ms_sql
    exit_code, log_size_mb = run_bash %q( ghe-mssql-console -y -n -q "
        SET NOCOUNT ON;
        SELECT cntr_value/1024.0 AS [Log Size (MB)]
        FROM   sys.dm_os_performance_counters
        WHERE  instance_name = '_Total'
               AND object_name LIKE '%Databases%'
               AND counter_name = 'Log File(s) Size (KB)'
               AND cntr_value > 0
        " 2>&1)

    log_size_mb.strip!

    return fail("Could not check for transation log size") unless exit_code == 0

    log_size_mb = log_size_mb.to_i
    log_detail "MSSQL Transation Log Size #{log_size_mb} MB"

    _, data_user_disk_size_mb = run_bash %q( echo "select blocks*blocks_size/(1024 * 1024) from mounts where path = '/data/user';" | osqueryi --list --noheader 2>&1 )
    data_user_disk_size_mb = data_user_disk_size_mb.to_i

    log_detail "/user/data size #{data_user_disk_size_mb} MB"

    return fail("Could not find /user/data size") unless data_user_disk_size_mb > 0

    disk_usage_percent = (log_size_mb * 100) / data_user_disk_size_mb

    return fail("MSSQL Transaction Logs are using #{disk_usage_percent}% or /data/user, which is not less than 15%") unless disk_usage_percent < 15

    pass "MSSQL Transaction Logs are using #{disk_usage_percent}% or /data/user, which is less than 15%"
  end
end

class MSSqlUnableToReadInstanceId < Checks::MsSqlDiagnostic
  name "MSSQL Unable to read instance id"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/90"

  def check_ms_sql
    exit_code, _ = run_bash 'grep -r -F "sqlservr: Unable to read instance id from /var/opt/mssql/.system/instance_id" /data/user/nomad/alloc 2>&1'

    if exit_code == 0
      fail "Unable to read instance id detected"
    else
      pass "No problems reading instance id id detected"
    end
  end
end

$checks_to_run += [
  MSSqlPageAllocationFailures,
  MSSqlAllocatedMemory,
  MSSqlOomMemoryAllocationFailures,
  MSSqlHealthCheck,
  MSSqlStateCheck,
  MSSqlMissingAvailabilityGroup,
  MSSqlSeedingInProgress,
  MSSqlReplicaState,
  MSSqlDatabaseBackups,
  MSSqlTransactionLogs,
  MSSqlUnableToReadInstanceId,
]