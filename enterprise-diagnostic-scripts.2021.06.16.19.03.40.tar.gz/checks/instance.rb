#!/usr/bin/env ruby

require "checks.rb"
require "helper.rb"

class MaintenanceMode < Checks::Base
  name "Maintenance Mode"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/35"

  def run
    exit_code, _ = run_bash "ghe-maintenance -q 2>&1"
    unless exit_code == 1
      fail "The instance is in maintenance mode"
    else
      pass "The instance is not in maintenance mode"
    end
  end
end

$checks_to_run += [
  MaintenanceMode,
]