#!/usr/bin/env ruby

require "checks.rb"

class NomadJobsFailures < Checks::Base
  name "Nomad Jobs Failures"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/44"

  def run
    return skipped("No ghe-config.log file") unless File.file?('/data/user/common/ghe-config.log')

    # Looking for '==> Evaluation "73931e44" finished with status "failed"'
    exit_code, _ = run_bash %q( grep '==> Evaluation ".*" finished with status "failed"' /data/user/common/ghe-config.log 2>&1 )

    return fail("Found evidence of failed nomad Jobs") if exit_code == 0

    pass "No evidence of failed Nomad Jobs"
  end
end

$checks_to_run += [
  NomadJobsFailures,
]
