#!/usr/bin/env ruby

require "checks.rb"
require "helper.rb"

class TotalMemory < Checks::Base
  name "Total Memory"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/6"

  def run
    min_memory_gb = Helper.get_min_memory_gb(active_seats)
    _, total_memory_gb = run_bash 'echo "select memory_total/(1024 * 1024 * 1024) from memory_info;" | osqueryi --list --noheader 2>&1'
    total_memory_gb = total_memory_gb.to_i
    unless total_memory_gb < min_memory_gb
      pass "Total memory #{total_memory_gb}GB is above the min #{min_memory_gb}GB"
    else
      fail "Total memory #{total_memory_gb}GB is less than the min #{min_memory_gb}GB"
    end
  end
end

# This Check is not checking the correct thing see https://github.com/github/enterprise-diagnostic-scripts/issues/81
class RootDiskSize < Checks::Base
  name "Root Disk Size"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/6"

  MIN_ROOT_DISK_SIZE_GB = 200

  def run
    _, root_disk_size_gb = run_bash %q( echo "select blocks*blocks_size/(1024 * 1024 * 1024) from mounts where path = '/';" | osqueryi --list --noheader 2>&1 )
    root_disk_size_gb = root_disk_size_gb.to_i
    unless root_disk_size_gb < MIN_ROOT_DISK_SIZE_GB
      pass "Total Root Disk #{root_disk_size_gb}GB is above the min #{MIN_ROOT_DISK_SIZE_GB}GB"
    else
      fail "Total Root Disk #{root_disk_size_gb}GB is less than the min #{MIN_ROOT_DISK_SIZE_GB}GB"
    end
  end
end

class VCPURequirements < Checks::Base
  name "Virtual CPU requirements"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/6"

  def run
    _, vcpu_count = run_bash %q( echo "select cpu_logical_cores from system_info;" | osqueryi --list --noheader 2>&1 )
    vcpu_count = vcpu_count.to_i
  
    min_vcpus = Helper.get_min_vcpus(active_seats)
    unless vcpu_count < min_vcpus
      pass "The instance has #{vcpu_count} vCPUs meets the required #{min_vcpus} based on the number of active users"
    else
      fail "The number of vCPUs the instance has (#{vcpu_count}) is less than the requirement (#{min_vcpus}) for the the number of active users."
    end
  end
end

$checks_to_run += [
  TotalMemory,
  # RootDiskSize,  Commenting this one out until we can fix https://github.com/github/enterprise-diagnostic-scripts/issues/81
  VCPURequirements,
]