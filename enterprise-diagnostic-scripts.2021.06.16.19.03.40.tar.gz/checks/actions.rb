#!/usr/bin/env ruby

require "checks.rb"

module Checks

  class ActionsDiagnostic < Base

    def check_actions
      # Define in child classes
    end

    def run
      return skipped("Slow Check") unless run_slow?

      exit_code, _ = run_bash "ghe-config --true app.actions.enabled 2>&1"
      return skipped("Actions is not enabled") unless exit_code == 0

      check_actions
    end
  end
end

class ActionsCheck < Checks::ActionsDiagnostic
  name "Run ghe-actions-check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/36"

  def check_actions
    exit_code, _ = run_bash "ghe-actions-check 2>&1"
    if  exit_code == 0
      pass "Passed basic checks"
    else
      fail "Failed basic Actions check"
    end
  end
end

class ActionsServicesConnectivity < Checks::ActionsDiagnostic
  name "Actions Services Connectivity"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/25"

  def check_actions
    ACTIONS_SERVICES.each do |source|
      ACTIONS_SERVICES.each do |target|
        unless source == target
          exit_code, _ = run_bash "ghe-actions-check-connectivity --source #{source} --target #{target} 2>&1"
          return fail("#{source} could not communicate with #{target}") unless exit_code == 0
        end
      end
    end
    pass "All Actions Services can Communicate"
  end
end

class ValidateStarterWorkflows < Checks::ActionsDiagnostic
  name "Validate Starter Workflows"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/51"

  def check_actions
    # Find the commit that the repo is on
    exit_code, commit_sha = run_bash "git --git-dir=/data/ghes-actions/current/repos/actions_starter-workflows/.git rev-parse HEAD 2>&1"
    return fail("Failed to find commit sha for /data/ghes-actions/current/repos/actions_starter-workflows") unless exit_code == 0

    commit_sha.strip!

    # Find the actions org, it is not always called actions
    exit_code, actions_org = run_bash "ghe-config app.actions.actions-org"
    return fail("Failed to find commit actions org name") unless exit_code == 0

    actions_org.strip!

    # now look if appliance knows about this commit
    ruby_command = "puts Repository.nwo('#{actions_org}/starter-workflows').commits.exist?('#{commit_sha}')"
    exit_code, text = run_bash " echo \"#{ruby_command}\" | github-env bin/safe-ruby -r ./config/environment 2>&1 "
    text.strip!
    if exit_code == 0 && "true".eql?(text)
      pass "The appliance has the correct commit"
    else
      fail "The appliance's starter-workflow is not up to date"
    end
  end
end

class ActionsStateMatchesDBs < Checks::ActionsDiagnostic
  name "Actions State Matches DBs"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/60"

  def check_actions
    ACTIONS_SERVICES.each do |service|
      # get state
      _, state = run_bash "cat /data/user/actions/states/#{service.downcase}_state 2>&1"
      state.strip!

      # get database
      _, database_info = run_bash "ghe-actions-console -s #{service} -c '(dir ConfigDbName).Value' 2>&1"
      matches = database_info.match /(?:.*)> (?<database_name>.*)/
      unless matches.nil?
        database_name = matches[:database_name]

        return fail("Found unexpected character in database name #{database_name}") if database_name.include? "'"

        sql = "
        SET NOCOUNT ON;
        SELECT COUNT(1) 
        FROM   sys.databases
        WHERE  name = '#{database_name}'"
        _, database_info = run_bash "ghe-mssql-console -y -n -q \"#{sql}\" 2>&1"
        database_info.strip!
      end

      if "1".eql? database_info
        log_detail "Found #{database_name}"
        return fail("MSSQL Database #{database_name} exists, but state file indicates it should not") unless ["complete", "created", "connected"].include? state
      end

    end
    pass "All Actions States match DBs"
  end
end

class ActionsCheckReservedNames < Checks::ActionsDiagnostic
  name "Check GitHub Actions Reserved Users"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/62"

  def check_actions
    _, actions_org = run_bash %q( ghe-config app.actions.actions-org )
    actions_org.strip!
    if actions_org.empty?
      exit_code, result_count = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT count(*) FROM users WHERE users.login IN (\"actions\", \"github-actions\", \"github-actions-org\");" | tail -n1 )
      return fail("Could not access the the mysql table(s)") unless exit_code == 0
      return fail("All reserved actions org names are taken") if result_count.strip.to_i == 3
    else
      exit_code_user, result_user = run_bash %Q( /usr/local/share/enterprise/github-mysql "SELECT users.login FROM users WHERE users.login=\\"#{actions_org}\\" AND users.type=\\"Organization\\";" )
      return fail("Could not access the the mysql table(s)") unless exit_code_user == 0
      return fail("There is not an existing organization that corresponds to the configured actions org (app.actions.actions-org)") if result_user.empty?
    end
    pass "All reserved users are available"
  end
end

class ActionsCheckIntegrationConfiguration < Checks::ActionsDiagnostic
  name "Check GitHub-Actions Bot Integration"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/62"

  def check_actions
    exit_code_bot, result_bot = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT users.login, users.id FROM users INNER JOIN integrations ON users.id=integrations.bot_id WHERE users.login=\"github-actions[bot]\" AND integrations.name=\"GitHub Actions\";" )

    return fail("Could not access the the mysql table(s)") unless exit_code_bot == 0
    return fail("There is no GitHub-Actions bot associated with a user") if result_bot.empty?
    
    pass "The GitHub-Actions bot integration is configured correctly"
  end
end

$checks_to_run += [
  ActionsCheck,
  ActionsServicesConnectivity,
  ValidateStarterWorkflows,
  ActionsStateMatchesDBs,
  ActionsCheckReservedNames,
  ActionsCheckIntegrationConfiguration,
]
